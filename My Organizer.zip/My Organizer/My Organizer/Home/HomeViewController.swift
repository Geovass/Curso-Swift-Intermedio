//
//  HomeViewController.swift
//  My Organizer
//
//  Created by alumno on 14/02/23.
//

import Foundation
import UIKit

class HomeViewController: UIViewController {
    
    var user = User(name: "", edad: 0, email: "", password: "")
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //setUpUI()
    }
}
