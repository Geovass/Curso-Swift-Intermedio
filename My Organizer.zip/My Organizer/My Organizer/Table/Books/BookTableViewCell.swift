//
//  BookTableViewCell.swift
//  My Organizer
//
//  Created by alumno on 14/02/23.
//

import UIKit

class BookTableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var bookImage: UIImageView!
    @IBOutlet weak var bookNameLabel: UILabel!
    @IBOutlet weak var authorLabel: UILabel!
    @IBOutlet weak var numberOfPagesLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        setUpUI()
    }
    
    func setUp(withBook book: Book){
        bookNameLabel.text = book.bookName
        descriptionLabel.text = book.description
    }
    
    private func setUpUI(){
        bookImage.layer.cornerRadius = bookImage.bounds.height / 2
        bookImage.image = UIImage(systemName: "character.book.closed.zh.traditional")
        
    }
}
