//
//  VistaStepper.swift
//  Landmarks
//
//  Created by alumno on 09/02/23.
//

import SwiftUI

struct VistaStepper: View {
    
    @State var value = 0
    let step = 5
    let range = 1...50
    let colors: [Color] = [.orange, .blue, .white, .pink, .red, .purple, .yellow, .gray, .green, .black, .brown, .cyan, .indigo, .mint, .secondary, .teal]
    func incremento(){
        value += 1
        if value >= colors.count{
            value = 0
        }
    }
    
    func decremento(){
        value -= 1
        if value < 0{
            value = colors.count-1
        }
    }
    
    var body: some View {
        VStack{
            Stepper("Valor: \(value), step: \(step)", value: $value, in: range, step: step)
            Stepper{
                Text("Valor: \(value) Color: \(colors[value].description)")
            }onIncrement: {
                incremento()
            }onDecrement: {
                decremento()
            }
            .padding()
            .background(colors[value])
        }
    }
}

struct VistaStepper_Previews: PreviewProvider {
    static var previews: some View {
        VistaStepper()
    }
}
