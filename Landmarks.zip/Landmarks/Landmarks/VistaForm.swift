//
//  VistaForm.swift
//  Landmarks
//
//  Created by alumno on 09/02/23.
//

import SwiftUI

struct VistaForm: View {
    @State private var username = ""
    var body: some View {
        VStack{
            Form{
                Text("Hola!")
                Text("Mi nombre es...")
                TextField("Nombre: ",text: $username)
            }
        }
    }
}

struct VistaForm_Previews: PreviewProvider {
    static var previews: some View {
        VistaForm()
    }
}
