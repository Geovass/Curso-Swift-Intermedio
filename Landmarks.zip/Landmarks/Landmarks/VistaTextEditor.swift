//
//  VistaTextEditor.swift
//  Landmarks
//
//  Created by alumno on 08/02/23.
//

import SwiftUI

struct VistaTextEditor: View {
    @State var text = ""
    
    var body: some View {
        VStack{
            TextEditor(text: $text)
                .onChange(of: text){
                    newValue in
                    print(newValue)
                }
        }
    }
}

struct VistaTextEditor_Previews: PreviewProvider {
    static var previews: some View {
        VistaTextEditor()
    }
}
