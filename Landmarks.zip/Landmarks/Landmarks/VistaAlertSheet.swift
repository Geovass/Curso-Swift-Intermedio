//
//  VistaAlertSheet.swift
//  Landmarks
//
//  Created by alumno on 09/02/23.
//

import SwiftUI

struct VistaAlertSheet: View {
    
    @State private var showinOptions = false
    @State private var selection = "Ninguno"
    
    var body: some View {
        VStack{
            Text(selection)
            
            Button("Confirma la seleccion"){
                showinOptions = true
            }.confirmationDialog("Elige un color", isPresented: $showinOptions){
                ForEach(["Rojo", "Azul", "Morado"], id: \.self){
                    color in
                    Button(color){
                        selection = color
                    }
                }
            }
        }
    }
}

struct VistaAlertSheet_Previews: PreviewProvider {
    static var previews: some View {
        VistaAlertSheet()
    }
}
