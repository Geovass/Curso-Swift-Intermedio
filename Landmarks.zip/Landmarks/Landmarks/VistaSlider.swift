//
//  VistaSlider.swift
//  Landmarks
//
//  Created by alumno on 09/02/23.
//

import SwiftUI

struct VistaSlider: View {
    
    @State var isEditing = false
    @State var volumen = 50.0
    
    var body: some View {
        VStack{
            Slider(
                value: $volumen,
                in: 0...100,
                step: 2.5
            ){
                Text("Volumen")
            }
        minimumValueLabel: {
            Text("0")
        }
        maximumValueLabel: {
            Text("100")
        }
        onEditingChanged: {
            editing in
            isEditing = editing
        }
            Text("\(volumen, specifier: "%.1f")")
                .foregroundColor(isEditing ? .red : .blue)
        }
    }
}

struct VistaSlider_Previews: PreviewProvider {
    static var previews: some View {
        VistaSlider()
    }
}
