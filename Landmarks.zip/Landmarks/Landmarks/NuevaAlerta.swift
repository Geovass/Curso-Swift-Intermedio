//
//  NuevaAlerta.swift
//  Landmarks
//
//  Created by alumno on 09/02/23.
//

import SwiftUI

/*struct NuevaAlerta: View {
    @State var showAlert = false
    var body: some View {
        Button("Show Alert"){
            showAlert = true
        }.alert(isPresented: $showAlert){
            Button("Hola"){}
            Button("Adios"){}
            Button("Ok"){}
            Button("Cancelar", role: .cancel){}
            Button("Borrar", role: .destructive){}
        }
    }
}

struct NuevaAlerta_Previews: PreviewProvider {
    static var previews: some View {
        NuevaAlerta()
    }
}*/
