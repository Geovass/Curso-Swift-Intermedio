//
//  ej2.swift
//  Landmarks
//
//  Created by alumno on 08/02/23.
//

import SwiftUI

struct ej2: View {
    
    @State var text = ""
    @State var counter: Int = 0
    
    var body: some View {
        VStack{
            Text("Contador")
            TextEditor(text: $text)
                .padding()
                .frame(width: 200, height: 100)
                .overlay(
                    RoundedRectangle(cornerRadius: 25)
                        .stroke(Color.secondary, lineWidth: 3)
                )
                .onChange(of: text, perform: { value in
                    counter = value.count
       
                    }
                )
            
            
            Text("\(counter) / 15")
                .foregroundColor(counter <= 15 ? .green : .red)
                .font(.largeTitle)
            
                
        }
    }
}

struct ej2_Previews: PreviewProvider {
    static var previews: some View {
        ej2()
    }
}
