//
//  VistaDatePicker.swift
//  Landmarks
//
//  Created by alumno on 08/02/23.
//

import SwiftUI

struct VistaDatePicker: View {
    
    @State var fecha = Date.now
    
    var body: some View {
        VStack{
            DatePicker(selection: $fecha){
                Text("Fecha de cita:")
            }
            .datePickerStyle(GraphicalDatePickerStyle())
            Text("Fecha de la cita: \(fecha.formatted(date: .long, time: .shortened))")
            
            DatePicker("Fecha", selection: $fecha, displayedComponents: .date)
            
            DatePicker("Fecha cita", selection: $fecha, in : Date.now...Date.now.addingTimeInterval(86400), displayedComponents: .date)
        }
    }
}

struct VistaDatePicker_Previews: PreviewProvider {
    static var previews: some View {
        VistaDatePicker()
    }
}
