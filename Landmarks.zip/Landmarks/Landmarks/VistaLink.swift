//
//  VistaLink.swift
//  Landmarks
//
//  Created by alumno on 09/02/23.
//

import SwiftUI

/*struct VistaLink: View {
    var body: some View {
        /*VStack{
            URL(string: "http://ioslab.ingenieria.unam.mx")!,
        Label: {
            
        }
            Link(destination: URL(String: UIApplication.openSettingsURLString)!, label: "Ir a iOS Lab")*/
        }
    }
}

struct VistaLink_Previews: PreviewProvider {
    static var previews: some View {
        VistaLink()
    }
}*/
