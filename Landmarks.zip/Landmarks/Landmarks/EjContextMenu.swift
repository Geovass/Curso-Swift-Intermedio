//
//  VistaContextMenu.swift
//  Landmarks
//
//  Created by alumno on 09/02/23.
//

import SwiftUI

struct EjContextMenu: View {
    var body: some View {
        VStack{
        Text("Opciones de transporte")
            .contextMenu{
                Button{
                    print("Change country setting")
                }label: {
                    Label("Elige un pais", systemImage: "globe")
                }
                
                Button{
                    print("Enable geolocation")
                }label: {
                    Label("Detectar ubicacion", systemImage: "location.circle")
                }
                
                Menu("Transporte"){
                    Button{
                        
                    }label: {
                        Label("Avion", systemImage: "airplane")
                    }
                }
            }
        Text("Mas opciones")
                .contextMenu{
                    Button{
                        print("Descargar")
                    }label: {
                        Label("Download", systemImage: "square.and.arrow.down")
                    }
                    
                    Button{
                        print("Guardar en fotos")
                    }label: {
                        Label("Save to photos", systemImage: "photo.artframe")
                    }
                    
                    Menu("Image Editing"){
                        Button{
                            
                        }label: {
                            Label("Mark Up", systemImage: "pencil.tip.crop.circle")
                        }
                        Button{
                            
                        }label: {
                            Label("Crop", systemImage: "crop")
                        }
                        Button{
                            
                        }label: {
                            Label("Compress", systemImage: "rectangle.compress.vertical")
                        }
                    }
                    Button{
                        print("Compartir")
                    }label: {
                        Label("Share", systemImage: "square.and.arrow.up")
                    }
                }
            }
    }
}

struct EjContextMenu_Previews: PreviewProvider {
    static var previews: some View {
        EjContextMenu()
    }
}
