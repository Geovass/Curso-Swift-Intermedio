//
//  EjercicioBoton.swift
//  M
//
//  Created by MacBook 16 on 07/02/23.
//

import SwiftUI

struct EjercicioBoton: View {
    @State var contador = 0
    
    @State var On: Bool = true
    
    var body: some View {
        VStack{
            Button{
                self.On.toggle()
                print("valor: \(On)")
                
            } label: {
                Text(On ? "On" : "Off")
                    .foregroundColor(.white)
            }.padding()
                .background(
                    RoundedRectangle(cornerRadius: 5.0)
                        .fill(self.On ? Color.green : Color.blue))
            
            //melissammonsalvo@gmail.com
            
        }
        
        
    }
}

struct EjercicioBoton_Previews: PreviewProvider {
    static var previews: some View {
        EjercicioBoton()
    }
}
