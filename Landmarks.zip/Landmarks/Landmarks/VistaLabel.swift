//
//  VistaLabel.swift
//  Landmarks
//
//  Created by alumno on 07/02/23.
//

import SwiftUI

struct VistaLabel: View {
    var body: some View {
        VStack{
            Label("<-- This is your life on an icon", systemImage: "gobackward")
                .font(.system(size: 20))
                //.labelStyle(IconOnlyLabelStyle())
            
            Label{
                Text("Fly over the skies")
            } icon: {
                /*Image("VON")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 200, height: 200)*/
                //Image(systemName: "paperplane.fill")
                Circle()
                    .fill(.red)
                    .frame(width: 60, height: 60)
                    .overlay(Text("Honey"))
                    .foregroundColor(.white)
            }
            
            Label{
                Text("Geovanni")
                    .foregroundColor(.purple)
                Text("Romero")
                    .foregroundColor(.red)
                    .opacity(0.3)
            } icon: {
                Circle()
                    .fill(.purple)
                    .frame(width: 60, height: 60)
                    .overlay(Text("GR"))
                    .foregroundColor(.white)
            }
            
        }
    }
}

struct VistaLabel_Previews: PreviewProvider {
    static var previews: some View {
        VistaLabel()
    }
}
