//
//  ej3.swift
//  Landmarks
//
//  Created by alumno on 08/02/23.
//

import SwiftUI

struct ej3: View {
    
    @State var color: Color = .red
    @State var fondo: Color = .red
    
    var body: some View {
        ZStack{
            color.ignoresSafeArea()
            ColorPicker("Elige tu color de fondo:", selection: $color, supportsOpacity: false)
        }
    }
}

struct ej3_Previews: PreviewProvider {
    static var previews: some View {
        ej3()
    }
}
