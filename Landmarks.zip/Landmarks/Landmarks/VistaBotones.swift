//
//  VistaBotones.swift
//  M
//
//  Created by MacBook 16 on 07/02/23.
//

import SwiftUI

struct VistaBotones: View {
    var body: some View {
        VStack{
            Button("Pausa", action: pausa )
            
            Button(action: pausa){
                Text("Pausa 2")
                    .foregroundColor(Color.pink)
            }
            
            Button("Pausa 3"){
                print("Accion 1")
                pausa()
            }
            
            Button{
                //Accion
                print("mariposa")
            } label: {
                Image("VON")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 100, height: 100)
            }
            
            Button{
                print("Edit")
            } label: {
                Label("Edit", systemImage: "pencil")
            }
            
            
            Button("Boton 1"){pausa()}
                .buttonStyle(.bordered)
                .tint(.green)
            Button("Boton 2", role: .cancel){pausa()}
            
            
        }
            
    }
    func pausa(){
        print("Pausa")
    }
}

struct VistaBotones_Previews: PreviewProvider {
    static var previews: some View {
        VistaBotones()
    }
}
