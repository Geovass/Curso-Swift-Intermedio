//
//  VistaToggle_Previews.swift
//  Landmarks
//
//  Created by alumno on 09/02/23.
//

import SwiftUI

/*struct CheckBoxStyle: ToggleStyle{
    func makeBody(configuration: Configuration) -> some View {
        return HStack {
            configuration.label
            Spacer()
            Image(systemName: configuration.isOn ? "Check.circle.fill" : "circle")
                .resizable()
                .frame(width: 24, height: 24)
                .foregroundColor(configuration.isOn ? .purple : .gray)
                .font(.system(size: 20, weight: .bold, design: .default))
            configuration.isOn.toggle()
            }
    }
}

struct VistaToggle_Previews: View {
    
    @State var isOn: Bool = false
    
    var body: some View {
        Toggle("Toggle", isOn: $isOn).toggleStyle(CheckBoxStyle())
    }
}

struct VistaToggle_Previews_Previews: PreviewProvider {
    static var previews: some View {
        VistaToggle_Previews()
    }
}*/

struct CheckboxStyle: ToggleStyle {
 
    func makeBody(configuration: Self.Configuration) -> some View {
 
        return HStack {
 
            configuration.label
 
            Spacer()
 
            Image(systemName: configuration.isOn ? "checkmark.circle.fill" : "circle")
                .resizable()
                .frame(width: 24, height: 24)
                .foregroundColor(configuration.isOn ? .purple : .gray)
                .font(.system(size: 20, weight: .bold, design: .default))
                .onTapGesture {
                    configuration.isOn.toggle()
                }
        }
 
    }
}

struct iOSCheckboxToggleStyle: ToggleStyle {
    func makeBody(configuration: Configuration) -> some View {
        // 1
        Button(action: {

            // 2
            configuration.isOn.toggle()

        }, label: {
            HStack {
                // 3
                Image(systemName: configuration.isOn ? "checkmark.square" : "square")

                configuration.label
            }
        })
    }
}

struct Prueba: View {
    @State var isOn: Bool = false
 
    var body: some View {
        VStack{
            Toggle("Toggle",isOn: $isOn)
                //.toggleStyle(iOSCheckboxToggleStyle())
        
            Text("\(isOn.description)")
                .bold()
            
            Rectangle().frame(width: 100, height: 100)
                .foregroundColor(isOn ? .green: .red)
            

        }
    }
}

struct Prueba_Previews: PreviewProvider {
    static var previews: some View {
        Prueba()
    }
}
