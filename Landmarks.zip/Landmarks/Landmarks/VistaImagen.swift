//
//  VistaImagen.swift
//  Landmarks
//
//  Created by alumno on 07/02/23.
//

import SwiftUI

struct VistaImagen: View {
    var body: some View {
        VStack{
            Image("VON")
                .resizable()
                .scaledToFit()
                .frame(width: 200, height: 200)
                .opacity(0.5)
            Text("Von")
                .opacity(0.5)
        }
    }
}

struct VistaImagen_Previews: PreviewProvider {
    static var previews: some View {
        VistaImagen()
    }
}
