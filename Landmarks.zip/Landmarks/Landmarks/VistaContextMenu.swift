//
//  VistaContextMenu.swift
//  Landmarks
//
//  Created by alumno on 09/02/23.
//

import SwiftUI

struct VistaContextMenu: View {
    var body: some View {
        Text("Opciones de transporte")
            .contextMenu{
                Button{
                    print("Change country setting")
                }label: {
                    Label("Elige un pais", systemImage: "globe")
                }
                
                Button{
                    print("Enable geolocation")
                }label: {
                    Label("Detectar ubicacion", systemImage: "location.circle")
                }
                
                Menu("Transporte"){
                    Button{
                        
                    }label: {
                        Label("Avion", systemImage: "airplane")
                    }
                }
            }
    }
}

struct VistaContextMenu_Previews: PreviewProvider {
    static var previews: some View {
        VistaContextMenu()
    }
}
