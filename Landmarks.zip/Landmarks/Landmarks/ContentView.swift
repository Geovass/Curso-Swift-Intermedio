//
//  ContentView.swift
//  Landmarks
//
//  Created by alumno on 07/02/23.
//

import SwiftUI

struct ContentView: View {
    @State var tex = "Hola mundo"
    
    var body: some View {
        VStack {
            Text("Well then, everyone have a nice day qwertyuioplkjhgfdsvxbasjidhufbajgaduyfefvchvadcvadhvcbhvgdacvhdgvcueycvhvcdhgvcvduhvvcxkhgadhajvdhdvhdvhjdvdigefoiEOCJDCjIDAicvjfbvijjdfvbiebjdv", comment: "")
                .padding(.init(top: 5, leading: 0, bottom: 100, trailing: 10))
                
            
            Text("Well then, everyone have a nice day qwertyuioplkjhgfdsvxbasjidhufbajgaduyfefvchvadcvadhvcbhvgdacvhdgvcueycvhvcdhgvcvduhvvcxkhgadhajvdhdvhdvhjdvdigefoiEOCJDCjIDAicvjfbvijjdfvbiebjdv", comment: "")
                //.border(.red)
                .padding(.init(top: 30, leading: 50, bottom: 100, trailing: 50))
                .lineSpacing(10)
                .lineLimit(3)
                .truncationMode(.tail)
                .multilineTextAlignment(.center)
                .foregroundColor(.init(red: 0.4, green: 0.5, blue: 0.8))
                .font(.custom("Courier", fixedSize: 30))
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
