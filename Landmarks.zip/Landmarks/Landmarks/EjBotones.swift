//
//  EjBotones.swift
//  M
//
//  Created by MacBook 16 on 07/02/23.
//

import SwiftUI

struct EjBotones: View {
    @State var selected = false

    @State private var isPlaying: Bool = false
    
    @State var tapCount = 0
    var body: some View {
        VStack {
            Button{
                self.selected.toggle()
                print("valor: \(selected)")
            } label:{
            
                Text($selected.wrappedValue ?"On":"Off")
                    .foregroundColor(.white)
            }
            .padding(.all)
            .background(RoundedRectangle(cornerRadius: 5.0)
            .fill(self.selected ? Color.green : Color.red))
            
            Button(isPlaying ? "Pause" : "Play") {
                        isPlaying.toggle()
            }
            /*
            Button(selected ? "Pause" : "Play") {
                        selected.toggle()
            }
             */
            Button("Tap Count: \(tapCount)") {
                self.tapCount += 1
            }
        }
    }
}

struct EjBotones_Previews: PreviewProvider {
    static var previews: some View {
        EjBotones()
    }
}
