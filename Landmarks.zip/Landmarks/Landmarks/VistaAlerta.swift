//
//  VistaAlerta.swift
//  Landmarks
//
//  Created by alumno on 09/02/23.
//

import SwiftUI

struct VistaAlerta: View {
    
    @State var showAlert = false
    
    var body: some View {
        Button("Show Alert"){
            showAlert = true
        }.alert(isPresented: $showAlert){
            Alert(
                title: Text("404 File not found"),
                message: Text("No se pudo encontrar el archivo especificado"),
                primaryButton: .default(Text("Reintentar"), action: firstAction),
                secondaryButton: .destructive(Text("Regresar"), action: secondAction)
            )
        }
    }
    
    func firstAction(){
        print("Vuelve a intentarlo")
    }
    
    func secondAction(){
        print("Regresar al inicio")
    }
}

struct VistaAlerta_Previews: PreviewProvider {
    static var previews: some View {
        VistaAlerta()
    }
}
