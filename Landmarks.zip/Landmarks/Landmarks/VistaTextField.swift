//
//  VistaTextField.swift
//  Landmarks
//
//  Created by alumno on 08/02/23.
//

import SwiftUI

struct VistaTextField: View {
    @State private var username = ""
    @State private var email = ""
    @State private var telefono = ""
    @State private var numero: Int = 0
    
    var body: some View {
        VStack{
            TextField("Nombre: ",text: $username)
                .textFieldStyle(.roundedBorder)
                
            Text("Nombre: " + username)
            
            TextField("Correo: ", text: $email)
                .keyboardType(.emailAddress)
            
            TextField("Telefono: ", text: $telefono)
                .keyboardType(.numberPad)
            
            TextField("Telefono: ", value: $numero, formatter: NumberFormatter())
                .keyboardType(.numberPad)
            
            Text("Telefono: \(numero)")
        }
    }
}

struct VistaTextField_Previews: PreviewProvider {
    static var previews: some View {
        VistaTextField()
    }
}
