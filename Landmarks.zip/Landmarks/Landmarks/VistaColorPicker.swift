//
//  VistaColorPicker.swift
//  Landmarks
//
//  Created by alumno on 08/02/23.
//

import SwiftUI

struct VistaColorPicker: View {
    
    @State var color: Color = .blue
    
    var body: some View {
        VStack{
            ColorPicker("Elige un color", selection: $color, supportsOpacity: true)
        }
    }
}

struct VistaColorPicker_Previews: PreviewProvider {
    static var previews: some View {
        VistaColorPicker()
    }
}
