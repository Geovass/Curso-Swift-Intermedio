//
//  VistaPicker.swift
//  Landmarks
//
//  Created by alumno on 08/02/23.
//

import SwiftUI

struct VistaPicker: View {
    
    @State var options = ["Perro", "Gato", "Rana"]
    @State var select = "Perro"
    
    var body: some View {
        Picker("Elige una opcion:", selection: $select){
            ForEach(options, id: \.self){ item in
                Text(item)
            }
        }.pickerStyle(WheelPickerStyle())
    }
}

struct VistaPicker_Previews: PreviewProvider {
    static var previews: some View {
        VistaPicker()
    }
}
