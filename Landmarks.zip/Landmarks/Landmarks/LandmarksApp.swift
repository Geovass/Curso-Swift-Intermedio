//
//  LandmarksApp.swift
//  Landmarks
//
//  Created by alumno on 07/02/23.
//

import SwiftUI

@main
struct LandmarksApp: App {
    var body: some Scene {
        WindowGroup {
            //ContentView()
            VistaTextField()
        }
    }
}
