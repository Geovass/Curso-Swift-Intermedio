//
//  ContactTableViewCell.swift
//  ContactApp
//
//  Created by Cristian guillermo Romero garcia on 02/02/23.
//

import UIKit

class ContactTableViewCell: UITableViewCell {

    @IBOutlet weak var contactImageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var phoneNumberLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        setUpUI()
    }
    
    func setUp(withContact contact: Contact){
        nameLabel.text = contact.fullName
        phoneNumberLabel.text = contact.phoneNumber
    }
    
    
    private func setUpUI(){
        contactImageView.layer.cornerRadius = contactImageView.bounds.height / 2
        contactImageView.image = UIImage(named: "profileimage")
        
    }

   
    
}
