//
//  Contact.swift
//  ContactApp
//
//  Created by Cristian guillermo Romero garcia on 02/02/23.
//

import Foundation

struct Contact{
    let name: String
    let lastname: String
    let phoneNumber: String
    
    var fullName: String{
        return "\(self.name) \(self.lastname)"
    }
    
    init(name: String, lastname: String, phoneNumber: String) {
        self.name = name
        self.lastname = lastname
        self.phoneNumber = phoneNumber
    }
}
