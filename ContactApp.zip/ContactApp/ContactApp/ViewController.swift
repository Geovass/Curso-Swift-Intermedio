//
//  ViewController.swift
//  ContactApp
//
//  Created by Cristian guillermo Romero garcia on 02/02/23.
//

import UIKit

class ViewController: UIViewController {

    let contacts = [
        Contact(name: "Cristian", lastname: "Romero", phoneNumber: "5543421492"),
        Contact(name: "Pedro", lastname: "Rouin", phoneNumber: "5539072623"),
        Contact(name: "Diego", lastname: "Reyes", phoneNumber: "55466715652"),
        Contact(name: "Antonio", lastname: "Rodriguez", phoneNumber: "5543426792"),
        Contact(name: "Adriana", lastname: "Ruiz", phoneNumber: "554567421492"),
        Contact(name: "Elvin", lastname: "Juarez", phoneNumber: "55457921492"),
        Contact(name: "David", lastname: "Altamirano", phoneNumber: "5513421492"),
        Contact(name: "Antonio", lastname: "Arellano", phoneNumber: "5566621492"),
        Contact(name: "Antonio", lastname: "Rodriguez", phoneNumber: "5543426792"),
        Contact(name: "Adriana", lastname: "Ruiz", phoneNumber: "554567421492"),
        Contact(name: "Elvin", lastname: "Juarez", phoneNumber: "55457921492"),
        Contact(name: "David", lastname: "Altamirano", phoneNumber: "5513421492"),
        Contact(name: "Antonio", lastname: "Arellano", phoneNumber: "5566621492"),
        ]
    
    @IBOutlet weak var ContactTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpTableview()
        // Do any additional setup after loading the view.
    }
    
    private func setUpTableview(){
        ContactTableView.register(UINib(nibName: "ContactTableViewCell", bundle: .main), forCellReuseIdentifier: "ContactTableViewCell")
        ContactTableView.dataSource = self
        ContactTableView.delegate = self
    }


}

extension ViewController: UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return contacts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: "ContactTableViewCell", for: indexPath) as? ContactTableViewCell{
            let contact = contacts[indexPath.row]
            cell.setUp(withContact: contact)
            return cell
        }
        return UITableViewCell()
    }
    
    
}

extension ViewController: UITableViewDelegate{
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let contact = contacts[indexPath.row]
        print("CONTACT SELECTED: \(contact.fullName)")
        tableView.deselectRow(at: indexPath, animated: true)
        let secondStoryboard = UIStoryboard(name: "SecondStoryboard", bundle: .main)
        let secondViewController = secondStoryboard.instantiateViewController(withIdentifier: "SecondVC")
       // let navigation  = UINavigationController(rootViewController: secondViewController)
        secondViewController.modalPresentationStyle = .fullScreen
        self.present(secondViewController, animated: true)
        
        //let navigationController = UINavigationController(rootViewController: homeViewController)
       // self.navigationController?.pushViewController(secondViewController, animated: true)
    }
}
