//
//  HomeViewController.swift
//  Tarea1SwiftIntermedio
//
//  Created by JMartin Pacheco on 01/02/23.
//

import UIKit

class HomeViewController: UIViewController {

    let colorBase:UIColor = UIColor(red: 1, green: 142/255, blue: 36/255, alpha: 1)
    
    @IBOutlet weak var headerView: UIView!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblWelcome: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        setUpUI()
        setUpConstrains()
    }
    
    func setUpUI(){
        headerView.backgroundColor = colorBase
        headerView.translatesAutoresizingMaskIntoConstraints = false
        
        lblTitle.text = "Mi red social"
        lblTitle.font = UIFont(name: "Arial Rounded MT Bold", size: 22)
        lblWelcome.text = "Bienvenido, esta es una super red social."
        lblWelcome.textAlignment = .justified
    }
    func setUpConstrains(){
        headerView.heightAnchor.constraint(equalToConstant: 240).isActive = true
        headerView.widthAnchor.constraint(equalTo: view.widthAnchor).isActive = true
        headerView.topAnchor.constraint(equalTo: view.layoutMarginsGuide.topAnchor).isActive = true
    }

}
