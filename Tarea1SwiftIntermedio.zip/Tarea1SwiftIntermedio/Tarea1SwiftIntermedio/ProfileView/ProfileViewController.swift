//
//  ProfileViewController.swift
//  Tarea1SwiftIntermedio
//
//  Created by JMartin Pacheco on 01/02/23.
//

import UIKit

class ProfileViewController: UIViewController {
    
    var user : User?
    let colorBase:UIColor = UIColor(red: 1, green: 142/255, blue: 36/255, alpha: 1)
    
    @IBOutlet weak var lblNombre: UILabel!
    @IBOutlet weak var headerView: UIView!
    @IBOutlet weak var imgPerfil: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setUpUI()
        setUpConstrains()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        setUpUI()
    }
    
    func setUpUI(){
        lblNombre.text = user?.name
        lblNombre.font = UIFont(name: "Arial Rounded MT Bold", size: 22)
        headerView.backgroundColor = colorBase
        headerView.translatesAutoresizingMaskIntoConstraints = false
        
        imgPerfil.image = UIImage(named: "spidey")
        imgPerfil.contentMode = .scaleAspectFit
        imgPerfil.layer.cornerRadius = imgPerfil.bounds.height / 2
    }
    func setUpConstrains(){
        headerView.heightAnchor.constraint(equalToConstant: 240).isActive = true
        headerView.widthAnchor.constraint(equalTo: view.widthAnchor).isActive = true
        headerView.topAnchor.constraint(equalTo: view.layoutMarginsGuide.topAnchor).isActive = true
    }
    

}
