//
//  UserModel.swift
//  Tarea1SwiftIntermedio
//
//  Created by JMartin Pacheco on 09/02/23.
//

import Foundation

struct User {
    var name:String
    let edad:Int
    let email:String
    var pass:String
    
    init(name: String, edad: Int, email: String, pass: String) {
        self.name = name
        self.edad = edad
        self.email = email
        self.pass = pass
    }
}
