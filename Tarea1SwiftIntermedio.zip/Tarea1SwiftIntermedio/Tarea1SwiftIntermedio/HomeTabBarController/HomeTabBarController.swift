//
//  HomeTabBarController.swift
//  Tarea1SwiftIntermedio
//
//  Created by JMartin Pacheco on 08/02/23.
//
import Foundation
import UIKit

class HomeTabBarController: UITabBarController {

    var user:User?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        setupViewController()
    }
        
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
                
        let navVC = self.viewControllers?[0] as! UINavigationController
        let perfil = navVC.topViewController as! ProfileViewController
        perfil.user = user
        
        let navVC2 = self.viewControllers?[2] as! UINavigationController
        let config = navVC2.topViewController as! SettingsViewController
        config.user = user
        config.perfil = perfil
    }

    private func setupViewController(){
        //primer item
        let firstStory = UIStoryboard(name: "ProfileStoryboard", bundle: .main)
        let firstController = firstStory.instantiateViewController(withIdentifier: "ProfileVC")
        let firstNavigation = UINavigationController(rootViewController: firstController)
        
        firstNavigation.tabBarItem.title = "Profile"
        firstNavigation.tabBarItem.image = UIImage(systemName: "person.circle")
        firstNavigation.tabBarItem.selectedImage = UIImage(systemName: "person.circle.fill")
        
        //segundo item
        let secondStory = UIStoryboard(name: "HomeStoryboard", bundle: .main)
        let secondController = secondStory.instantiateViewController(withIdentifier: "HomeVC")
        let secondNavigation = UINavigationController(rootViewController: secondController)
        
        secondNavigation.tabBarItem.title = "Home"
        secondNavigation.tabBarItem.image = UIImage(systemName: "house.circle")
        secondNavigation.tabBarItem.selectedImage = UIImage(systemName: "house.circle.fill")
        
        //tercer item
        let thirdStory = UIStoryboard(name: "SettingsStoryboard", bundle: .main)
        let thirdController = thirdStory.instantiateViewController(withIdentifier: "SettingsVC")
        let thirdNavigation = UINavigationController(rootViewController: thirdController)
        
        thirdNavigation.tabBarItem.title = "Setting"
        thirdNavigation.tabBarItem.image = UIImage(systemName: "pencil.circle")
        thirdNavigation.tabBarItem.selectedImage = UIImage(systemName: "pencil.circle.fill")
        
        let homeControllers:[UIViewController] = [firstNavigation, secondNavigation, thirdNavigation]
        self.viewControllers = homeControllers
        self.selectedIndex = 1
    }

}
