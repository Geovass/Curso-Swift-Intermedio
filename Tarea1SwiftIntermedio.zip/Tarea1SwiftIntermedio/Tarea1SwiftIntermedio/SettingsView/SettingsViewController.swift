//
//  SettingsViewController.swift
//  Tarea1SwiftIntermedio
//
//  Created by JMartin Pacheco on 01/02/23.
//

import UIKit

class SettingsViewController: UIViewController {
    
    var user : User?
    var perfil : ProfileViewController?
    
    let colorBase:UIColor = UIColor(red: 1, green: 142/255, blue: 36/255, alpha: 1)
    
    @IBOutlet weak var lblData: UILabel!
    
    @IBOutlet weak var lblUser: UILabel!
    @IBOutlet weak var inputUser: UITextField!
    @IBOutlet weak var lblPassOld: UILabel!
    @IBOutlet weak var inputPassOld: UITextField!
    @IBOutlet weak var lblPassNew: UILabel!
    @IBOutlet weak var inputPassNew: UITextField!
    
    @IBOutlet weak var btnUpdate: UIButton!
    @IBOutlet weak var lblSuccess: UILabel!
    
    @IBAction func btnUpdatePressed(_ sender: Any) {
        let password = String(user?.pass ?? "")
        
        guard let passNew = inputPassNew.text,
              let passOld = inputPassOld.text,
              let nombre = inputUser.text
        else{
            return
        }
        
        if nombre.isEmpty || passOld.isEmpty || passNew.isEmpty {
            showAlert("Error", "Ingresa todos los campos")
        }
        else if passOld != password {
            showAlert("Error", "La contraseña anterior no coincide")
        }
        else{
            user?.name = nombre
            user?.pass = passNew
            perfil?.user = user
            
            lblSuccess.text = "Datos actualizados"
            lblSuccess.isHidden = false
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpUI()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        setUpUI()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    func showAlert(_ titulo:String, _ mensaje:String){
        let alertController = UIAlertController(title: titulo, message: mensaje, preferredStyle: .alert)
        let aceptAction = UIAlertAction(title: "Aceptar", style: .default)
        
        alertController.addAction(aceptAction)
        self.present(alertController, animated: true, completion: nil)
    }
    
    func setUpUI(){
        let email = String(user?.email ?? "")
        let usuario = String(user?.name ?? "")
        
        lblData.text = "Hola " + email
        lblUser.text = "Username"
        lblPassOld.text = "Password anterior"
        lblPassNew.text = "Password nueva"
        
        inputUser.text = usuario
        inputPassOld.text = ""
        inputPassOld.isSecureTextEntry = true
        inputPassNew.text = ""
        inputPassNew.isSecureTextEntry = true
        btnUpdate.setTitle("Actualizar", for: .normal)
        btnUpdate.tintColor = colorBase
        btnUpdate.layer.cornerRadius = 10
        lblSuccess.isHidden = true
        
    }
}
