//
//  RegisterViewController.swift
//  Tarea1SwiftIntermedio
//
//  Created by JMartin Pacheco on 08/02/23.
//

import UIKit

class RegisterViewController: UIViewController {

    @IBOutlet weak var inputPassword: UITextField!
    @IBOutlet weak var inputCorreo: UITextField!
    @IBOutlet weak var inputUser: UITextField!
    @IBOutlet weak var lblPassword: UILabel!
    @IBOutlet weak var lblCorreo: UILabel!
    @IBOutlet weak var lblUser: UILabel!
    @IBOutlet weak var lblEdad: UILabel!
    @IBOutlet weak var sliderEdad: UISlider!
    @IBOutlet weak var lblAge: UILabel!
    
    @IBOutlet weak var btnCreate: UIButton!
    
    let colorBase:UIColor = UIColor(red: 1, green: 142/255, blue: 36/255, alpha: 1)
    
    override func viewDidLoad() {
        super.viewDidLoad()

        setUpUI()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    @IBAction func sliderAgeChanged(_ sender: Any) {
        let edad:Int = Int(sliderEdad.value)
        lblAge.text = String(edad)
    }
    
    @IBAction func btnCreatePressed(_ sender: Any) {
        let edad = Int(sliderEdad.value)
        guard let user = inputUser.text,
              let pass = inputPassword.text,
              let correo = inputCorreo.text
        else{
            return
        }
        
        if user.isEmpty || pass.isEmpty || correo.isEmpty {
            showAlert("Error", "Ingresa todos los campos")
        }
        else{
            let homeController = HomeTabBarController()
            
            let user = User(name: user, edad: edad, email: correo, pass: pass)
            homeController.user = user
            
            homeController.modalPresentationStyle = .fullScreen
            self.present(homeController, animated: true)
        }
    }
    
    func showAlert(_ titulo:String, _ mensaje:String){
        let alertController = UIAlertController(title: titulo, message: mensaje, preferredStyle: .alert)
        let aceptAction = UIAlertAction(title: "Aceptar", style: .default)
        
        alertController.addAction(aceptAction)
        self.present(alertController, animated: true, completion: nil)
    }
    
    func setUpUI(){
        lblUser.text = "Username"
        lblCorreo.text = "Email"
        lblPassword.text = "Password"
        lblEdad.text = "Edad"
        inputUser.placeholder = "Username"
        inputCorreo.placeholder = "Email"
        inputPassword.placeholder = "Password"
        inputPassword.isSecureTextEntry = true
        
        sliderEdad.minimumValue = 10
        sliderEdad.maximumValue = 90
        sliderEdad.tintColor = colorBase
        lblAge.text = "10"
        
        btnCreate.setTitle("Crear cuenta", for: .normal)
        btnCreate.layer.cornerRadius = 10
        btnCreate.tintColor = colorBase
        
        self.title = "Registro"
    }
    

}
