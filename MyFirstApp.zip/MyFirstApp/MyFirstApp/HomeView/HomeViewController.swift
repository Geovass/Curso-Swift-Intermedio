//
//  HomeViewController.swift
//  MyFirstApp
//
//  Created by alumno on 02/02/23.
//

import Foundation
import UIKit

class HomeViewController: UIViewController{
    
    var user = User(name: "", email: "", age: 0, phone: "")
    
    //MARK: Outlets
    
    
    @IBOutlet weak var welcomeLabel: UILabel!
    @IBOutlet weak var nameDescriptionLabel: UILabel!
    @IBOutlet weak var ageDescriptionLabel: UILabel!
    @IBOutlet weak var emailDescriptionLabel: UILabel!
    @IBOutlet weak var phoneDescriptionLabel: UILabel!
    @IBOutlet weak var ageLabel: UILabel!
    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var phoneLabel: UILabel!
    
    //MARK: Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("ViewDidLoad")
        print("User: \(user)")
        setUpUI()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        print("ViewWillAppear")
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        print("ViewDidAppear")
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        print("ViewWillDisappear")
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        print("ViewDidDisapear")
    }
    
    private func setUpUI(){
        welcomeLabel.text = "Bienvenido!"
        nameDescriptionLabel.text = user.name
        ageDescriptionLabel.text = "Edad"
        ageLabel.text = "\(user.age)"
        emailDescriptionLabel.text = "Email"
        emailLabel.text = user.email
        phoneDescriptionLabel.text = "Telefono"
        phoneLabel.text = user.phone
    }
}
