//
//  FirstViewController.swift
//  TabBarHome
//
//  Created by alumno on 02/02/23.
//

import UIKit

class FirstViewController: UIViewController {

    @IBOutlet weak var titleLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpUI()
        // Do any additional setup after loading the view.
    }
    
    private func setUpUI(){
        self.title = "First View"
        titleLabel.text = "First VC"
    }
}
