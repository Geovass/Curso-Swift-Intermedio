//
//  LoginViewController.swift
//  TabBarHome
//
//  Created by alumno on 02/02/23.
//

import UIKit

class LoginViewController: UIViewController {

    //MARK: Outlets
    
    @IBOutlet weak var signUpButton: UIButton!

    @IBOutlet weak var titleLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpUI()
        // Do any additional setup after loading the view.
    }
    
   @IBAction func buttonDidPressed(_ sender: Any){
        let homeViewController = HomeTabBarController()
        let navigationController = UINavigationController(rootViewController: homeViewController)
        self.navigationController?.pushViewController(homeViewController, animated: true)
    }
    
    func setUpUI(){
        self.title = "Log In View"
        titleLabel.text = "Log In"
        signUpButton.setTitle("Ingresar", for: .normal)
    }
}
