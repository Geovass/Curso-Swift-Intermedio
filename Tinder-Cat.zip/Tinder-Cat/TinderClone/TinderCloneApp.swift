//
//  TinderCloneApp.swift
//  TinderClone
//
//
//

import SwiftUI

@main
struct TinderCloneApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
